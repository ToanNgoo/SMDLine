﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace ManageMaterialPBA
{
    public partial class UpdateBOM : Form
    {
        database dtb = new database();
        database_1 dtb1 = new database_1();
        public string _user = string.Empty, _pass = string.Empty;

        public UpdateBOM(string user, string pass)
        {
            InitializeComponent();
            _user = user;
            _pass = pass;
        }

        private void UpdateBOM_Load(object sender, EventArgs e)
        {
            txt_lydo.Visible = false;
            txt_lydo.Enabled = false;
            label3.Visible = false;
            
            cbx_lydo.Items.Add("Thêm Code NVL mới");
            cbx_lydo.Items.Add("Thêm Maker mới");
            cbx_lydo.Items.Add("NVL được sử dụng");
            cbx_lydo.Items.Add("NVL không được sử dụng");
            cbx_lydo.Items.Add("Khác");
            //Load anh
            pictureBox1.Image = new Bitmap(@Application.StartupPath + "\\Picture\\SDIV.PNG");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            cbb_line.Items.Add("3");
            cbb_line.Items.Add("6");
            cbb_line.Items.Add("7");

            dtb1.delete_Transport("UpdateBOM");

            toolStripStatusLabel1.Text = dtb.get_name(_user, _pass);
        }

        private void cbb_line_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Delete database  
            OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
            cnn.Open();                             
            string strDel = "Delete * From UpdateBOM";
            OleDbCommand cmdDel = new OleDbCommand(strDel, cnn);
            cmdDel.ExecuteNonQuery();
            cnn.Close();

            cbb_mol.Text = "";
            cbb_mol.Items.Clear();
            try
            {
                string str = "select distinct Model from All_model1 Where Line='" + cbb_line.Text + "'";
                DataTable dt = new DataTable();
                dt = dtb.getData(str);

                // Add users vào comboBox
                foreach (DataRow dr in dt.Rows)
                {
                    if(dr.ItemArray[0] != null)
                    {
                        cbb_mol.Items.Add(dr.ItemArray[0].ToString());     
                    }                                                         
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Chọn Line trước nhé!", "UpdateBOM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cbb_mol_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Delete database  
            OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
            cnn.Open();
            string strDel = "Delete * From UpdateBOM";
            OleDbCommand cmdDel = new OleDbCommand(strDel, cnn);
            cmdDel.ExecuteNonQuery();
            cnn.Close();

            cbb_cod.Text = "";
            cbb_cod.Items.Clear();
            try
            {
                string str = "select distinct Ma_NVL from All_model1 Where Line='" + cbb_line.Text + "' And Model='" + cbb_mol.Text + "' order by Ma_NVL";
                DataTable dt = new DataTable();
                dt = dtb.getData(str);

                // Add users vào comboBox
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr.ItemArray[0] != null)
                    {
                        cbb_cod.Items.Add(dr.ItemArray[0].ToString());
                    }
                }
                cbb_cod.Items.Add("Blank");
            }
            catch (Exception)
            {
                MessageBox.Show("Chọn Line và Model trước nhé!", "UpdateBOM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cbb_cod_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Delete database  
            OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
            cnn.Open();
            string strDel = "Delete * From UpdateBOM";
            OleDbCommand cmdDel = new OleDbCommand(strDel, cnn);
            cmdDel.ExecuteNonQuery();
            cnn.Close();

            cbb_vendr.Text = "";
            cbb_vendr.Items.Clear();
            try
            {
                string str = "select distinct Maker from All_model1 Where Line='" + cbb_line.Text + "' And Model='" + cbb_mol.Text + "' And Ma_NVL='" + cbb_cod.Text + "'";
                DataTable dt = new DataTable();
                dt = dtb.getData(str);

                // Add users vào comboBox
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr.ItemArray[0] != null)
                    {
                        cbb_vendr.Items.Add(dr.ItemArray[0].ToString());
                    }
                }
                cbb_vendr.Items.Add("Blank");
            }
            catch (Exception)
            {
                MessageBox.Show("Chọn Line và Model và Code trước nhé!", "UpdateBOM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cbb_vendr_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgv_updBOM.Columns.Clear();
            //Hien thi datagridview
            DataTable dt = new DataTable();
            if (cbb_cod.Text != "Blank")
            {
                if(cbb_vendr.Text != "Blank")
                {
                    btn_upBOM.Text = "Update BOM";
                    //OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
                    //cnn.Open();

                    string str = "select distinct * from All_model1 Where Line='" + cbb_line.Text + "' And Model='" + cbb_mol.Text + "' And Ma_NVL='" + cbb_cod.Text + "' And Maker='" + cbb_vendr.Text + "'";
                    dt = dtb.getData(str);

                    ExportTxt(dt, @Application.StartupPath + "\\BOM\\Before_Update.txt", true);

                    //Hien thi datagridview
                    dtb.show_upBOM(dgv_updBOM, dt, false, true, true);
                }
                else//vendor = Blank
                {
                    btn_upBOM.Text = "Insert BOM";

                    string str = "select distinct Line, Model, Ma_NVL, Mo_ta, Vi_tri, Diem_gan, Cong_doan, Su_dung from All_model1 Where Line='" + cbb_line.Text + "' And Model='" + cbb_mol.Text + "' And Ma_NVL='" + cbb_cod.Text + "'";
                    dt = dtb.getData(str);

                    ExportTxt(dt, @Application.StartupPath + "\\BOM\\Before_Update.txt", false);

                    //Hien thi datagridview
                    DataTable dt2 = new DataTable();
                    StreamReader sr = new StreamReader(@Application.StartupPath + "\\BOM\\Before_Update.txt");
                    string[] colName = sr.ReadLine().Split('|');
                    for (int j = 0; j < colName.Length - 1; j++)
                    {
                        dt2.Columns.Add(colName[j]);
                    }

                    string newLine;
                    while ((newLine = sr.ReadLine()) != null)
                    {
                        DataRow dtr = dt2.NewRow();
                        string[] values = newLine.Split('|');
                        if (values[0] != "")
                        {
                            for (int i = 0; i < values.Length - 1; i++)
                            {
                                dtr[i] = values[i];
                            }
                            dt2.Rows.Add(dtr);
                        }
                    }
                    sr.Close();
                    dtb.show_upBOM(dgv_updBOM, dt2, false, false, true);
                }                              
            }
            else//code = blank
            {
                btn_upBOM.Text = "Insert BOM";

                OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
                cnn.Open();
                string strIn = string.Empty;
                strIn = "Insert Into UpdateBOM Values('" + cbb_line.Text + "','" + cbb_mol.Text  + "','" 
                                                         + "" + "','" + "" + "','" + "" + "','" + "" + "','"
                                                         + "" + "','" + "" + "','" + "SMD" + "','" + "" + "','" + "" + "')";
                OleDbCommand cmdIn = new OleDbCommand(strIn, cnn);// Khai báo và khởi tạo bộ nhớ biến cmd
                cmdIn.ExecuteNonQuery(); // thực hiện lênh SQL 
                cnn.Close();
                //Select all
                string str = "select * from UpdateBOM";
                dt = dtb.getData(str);

                ExportTxt(dt, @Application.StartupPath + "\\BOM\\Before_Update.txt", true);

                //Hien thi datagridview
                dtb.show_upBOM(dgv_updBOM, dt, false, false, false);
            }            
        }

        private void btn_upBOM_Click(object sender, EventArgs e)
        {
            if (dtb1.checkupBOM(dgv_updBOM, txt_lydo, cbx_lydo) == true)
            {
                MessageBox.Show("Các thông tin đang để trống hoặc sai format!", "UpdateBOM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                DialogResult anBom = MessageBox.Show("Bạn muốn update BOM?", "UpdateBOM", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (anBom == DialogResult.Yes)
                {
                    OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
                    cnn.Open();

                    foreach (DataGridViewRow dgr in dgv_updBOM.Rows)
                    {
                        if(dgr.Cells[0].Value != null)
                        {
                            if (cbb_cod.Text != "Blank" && cbb_vendr.Text != "Blank")//Update
                            {                                
                                string strUp = "Update All_model1 Set Vi_tri='" + dgr.Cells[4].Value.ToString() + 
                                                                       "', Diem_gan='" + dgr.Cells[5].Value.ToString() +
                                                                       "', Maker='" + dgr.Cells[6].Value.ToString() +
                                                                       "', Maker_Part='" + dgr.Cells[7].Value.ToString() +
                                                                       "', Cong_doan='" + dgr.Cells[8].Value.ToString() +
                                                                       "', So_luong='" + dgr.Cells[9].Value.ToString() + 
                                                                       "', Su_dung='" + dgr.Cells[10].Value.ToString() + 
                                                                       "' Where Line='" + cbb_line.Text + "' And Model='" + cbb_mol.Text + "' And Ma_NVL='" + cbb_cod.Text + "' And Maker='" + cbb_vendr.Text + "'";
                                OleDbCommand cmdUp = new OleDbCommand(strUp, cnn);
                                cmdUp.ExecuteNonQuery();
                                //Lưu data sau update
                                ExportTxt(dgv_updBOM, @Application.StartupPath + "\\BOM\\After_Update.txt");
                                CompareAndHistory(@Application.StartupPath + "\\BOM\\Before_Update.txt", @Application.StartupPath + "\\BOM\\After_Update.txt");
                            }
                            else//Insert
                            {
                                string strIn = "Insert Into All_model1 Values('" + dgr.Cells[0].Value.ToString() + "','" + dgr.Cells[1].Value.ToString() + "','" + dgr.Cells[2].Value.ToString() + "','" + dgr.Cells[3].Value.ToString() + "','"
                                                                                 + dgr.Cells[4].Value.ToString() + "','" + dgr.Cells[5].Value.ToString() + "','" + dgr.Cells[6].Value.ToString() + "','" + dgr.Cells[7].Value.ToString() + "','"
                                                                                 + dgr.Cells[8].Value.ToString() + "','" + dgr.Cells[9].Value.ToString() + "','" + dgr.Cells[10].Value.ToString() + "')";
                                OleDbCommand cmdIn = new OleDbCommand(strIn, cnn);
                                cmdIn.ExecuteNonQuery();
                                //Lưu data sau update
                                ExportTxt(dgv_updBOM, @Application.StartupPath + "\\BOM\\After_Update.txt");
                                CompareAndHistory(@Application.StartupPath + "\\BOM\\Before_Update.txt", @Application.StartupPath + "\\BOM\\After_Update.txt");                            
                            }
                        }                       
                    }

                    //Delete database                    
                    string strDel = "Delete * From UpdateBOM";
                    OleDbCommand cmdDel = new OleDbCommand(strDel, cnn);
                    cmdDel.ExecuteNonQuery();

                    cnn.Close();

                    dgv_updBOM.Columns.Clear();

                    //Select all
                    string str = "select * from All_model1 Where Line='" + cbb_line.Text + "' And Model ='" + cbb_mol.Text + "' order by Ma_NVL";
                    DataTable dt1 = dtb.getData(str);

                    //Hien thi datagridview
                    dtb.show_upBOM(dgv_updBOM, dt1, true, true, true);
                }
            }           
        }

        public void ExportTxt(DataTable dt1, string path, bool chk)
        {
            FileStream fs = new FileStream(path, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);

            StringBuilder sb = new StringBuilder();
            //Export header text
            
            sb.Append("Line|Model|Ma_NVL|Mo_ta|Vi_tri|Diem_gan|Maker|Maker_Part|Cong_doan|So_luong|Su_dung|");                                              
            
            sb.Append("\n");
            sw.WriteLine(sb);

            //Export data
            foreach(DataRow dr in dt1.Rows)
            {
                StringBuilder sbb = new StringBuilder();
                int j = 0;
                for (int i = 0; i < dt1.Columns.Count;)
                {
                    if(chk == false)
                    {
                        if(j == 6 || j == 7 || j == 9)
                        {
                            sbb.Append("");
                        }
                        else
                        {
                            sbb.Append(dr.ItemArray[i].ToString());
                            i++;
                        }
                    }
                    else
                    {
                        sbb.Append(dr.ItemArray[i].ToString());
                        i++;
                    }
                    
                    sbb.Append("|");
                    j++;
                }                   
                sw.WriteLine(sbb);

                break;              
            }
            sw.Close();
            fs.Close();
        }

        public void ExportTxt(DataGridView dtg1, string path)
        {
            FileStream fs = new FileStream(path, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);

            StringBuilder sb = new StringBuilder();
            //Export header text
            for (int i = 1; i < dtg1.Columns.Count + 1; i++)
            {

                sb.Append(dtg1.Columns[i - 1].HeaderText);
                sb.Append("|");//next sang cột bên cạnh                                   
            }
            sb.Append("\n");
            sw.WriteLine(sb);

            //Export data
            for (int n = 0; n <= dtg1.Rows.Count - 1; n++)
            {
                StringBuilder sbb = new StringBuilder();
                for (int j = 0; j < dtg1.Columns.Count; j++)
                {
                    if (dtg1.Rows[n].Cells[j].Value != null)
                    {
                        sbb.Append(dtg1.Rows[n].Cells[j].Value.ToString());
                        sbb.Append("|");
                    }
                }
                sw.Write(sbb);
            }
           
            sw.Close();
            fs.Close();
        }
        
        public void CompareAndHistory(string pathBef, string pathAft)
        {
            //Before
            StreamReader srBef = new StreamReader(pathBef);
            string[] strBef = new string[dgv_updBOM.Columns.Count];
            while(srBef.EndOfStream == false)
            {
                strBef = srBef.ReadLine().Split('|');                
            }
            srBef.Close();

            //After
            StreamReader srAft = new StreamReader(pathAft);
            string[] strAft = new string[dgv_updBOM.Columns.Count];
            while(srAft.EndOfStream == false)
            {
                strAft = srAft.ReadLine().Split('|');
            }
            srAft.Close();

            //So sánh
            string[] colName = new string[dgv_updBOM.Columns.Count];
            for (int j = 0; j < colName.Length; j++)
            {
                colName[j] = dgv_updBOM.Columns[j].Name;
            }

            string strLd = string.Empty;
            if (cbx_lydo.Text == "Khác")
            {
                strLd = txt_lydo.Text;
            }
            else
            {
                strLd = cbx_lydo.Text;
            }    

            for (int i = 0; i < strAft.Length; i++)
            {
                if (strBef[i] != strAft[i])
                {
                    OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
                    cnn.Open();
                    string strIn = "Insert Into HistoryBOM Values('" + DateTime.Now.ToShortDateString() + "','" + cbb_mol.Text + "','" + colName[i] + "','"
                                                                     + strBef[i] + "','" + strAft[i] + "','" + strLd + "','" 
                                                                     + toolStripStatusLabel1.Text + "','" + DateTime.Now.ToString() + "')";
                    OleDbCommand cmdIn = new OleDbCommand(strIn, cnn);
                    cmdIn.ExecuteNonQuery();
                    cnn.Close();
                }
            }
        }

        private void cbx_lydo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbx_lydo.Text == "Khác")
            {
                txt_lydo.Visible = true;
                txt_lydo.Enabled = true;
                label3.Visible = true;
            }
            else
            {
                txt_lydo.Visible = false;
                txt_lydo.Enabled = false;
                label3.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Nếu dùng dataGridView2.SelectedRows.Count thì phải click vào đầu hàng
                // Nếu dùng dataGridView2.CurrentRow.Index thì click vào bất kì vị trí có thể xóa hàng đó

                if (this.dgv_updBOM.CurrentRow.Index >= 0)
                {
                    dgv_updBOM.Rows.Remove(dgv_updBOM.CurrentRow);
                }
            }
            catch
            {
                MessageBox.Show("Click vào đầu hàng đó để xóa!", "UpdateBOM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
