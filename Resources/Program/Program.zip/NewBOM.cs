﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using Spire.Xls;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace ManageMaterialPBA
{
    public partial class NewBOM : Form
    {
        database dtb = new database();
        database_1 dtb1 = new database_1();
        DataTable dt = new DataTable();
        DataTable dt_mol = new DataTable();
        public string[] strArrNg;
        public int countNg;
        public string _user = string.Empty, _pass = string.Empty;

        public NewBOM(string user, string pass)
        {
            InitializeComponent();
            _user = user;
            _pass = pass;
        }

        private void NewBOM_Load(object sender, EventArgs e)
        {
            //Load anh
            pictureBox1.Image = new Bitmap(@Application.StartupPath + "\\Picture\\SDIV.PNG");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            groupBox2.Enabled = false;
            groupBox3.Enabled = false;

            //Xoa form dien data
            dgv_nwBOM.Columns.Clear();

            toolStripStatusLabel1.Text = dtb.get_name(_user, _pass);
        }

        private void btn_nmBOM_Click(object sender, EventArgs e)
        {
            if(dgv_nwBOM.Columns.Count != 11)
            {
                MessageBox.Show("Kiểm tra lại Form dữ liệu BOM chuẩn.\nDữ liệu bạn nhập đang thừa hoặc thiếu thông tin!", "NewBOM", MessageBoxButtons.OK, MessageBoxIcon.Information);              
            }
            else
            {               
                getNameColumns(0, 0, "Line");
                getNameColumns(1, 0, "Model");
                getNameColumns(2, 0, "Ma_NVL");
                getNameColumns(3, 0, "Mo_ta");
                getNameColumns(4, 0, "Vi_tri");
                getNameColumns(5, 0, "Diem_gan");
                getNameColumns(6, 0, "Maker");
                getNameColumns(7, 0, "Maker_Part");
                getNameColumns(8, 0, "Cong_doan");
                getNameColumns(9, 0, "So_luong");
                getNameColumns(10, 0, "Su_dung");
                
                if(strArrNg[0] != null)
                {
                    string toDisply = string.Join("\n", strArrNg);
                    MessageBox.Show("Trường dữ liệu bị sai.\nThay đổi lại như sau :\n" + toDisply, "NewBOM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    //all thong tin phai day du
                    if (dtb1.checkNwBOM(dgv_nwBOM) == true)
                    {
                        MessageBox.Show("Các thông tin đang để trống hoặc sai format!", "NewBOM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        DialogResult anBom = MessageBox.Show("Bạn muốn tạo BOM New Model?", "NewBOM", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (anBom == DialogResult.Yes)
                        {
                            if(chk_data(dgv_nwBOM) == false)//co loi data
                            {
                                DialogResult relBOM = MessageBox.Show("Thông tin BOM đang để trống hoặc sai format\nBạn có muốn tham khỏa file Master dữ liệu BOM?", "NewBOM", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                if(relBOM == DialogResult.Yes)
                                {
                                    System.Diagnostics.Process.Start(@Application.StartupPath + "\\Picture\\zMaterBOM.xlsx");
                                }
                            }
                            else
                            {
                                //update BOM database
                                OleDbConnection cnn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = " + Application.StartupPath + @"\Database.mdb"); //khai báo và khởi tạo biến cnn
                                cnn.Open();
                                foreach (DataGridViewRow dgr in dgv_nwBOM.Rows)
                                {
                                    if (dgr.Index == 0)
                                    {
                                        continue;
                                    }
                                    if (dgr.Cells[0].Value != null)
                                    {
                                        string strIn = "Insert Into All_model1 Values('" + dgr.Cells[0].Value.ToString() + "','" + dgr.Cells[1].Value.ToString() + "','" + dgr.Cells[2].Value.ToString() + "','"
                                                                                         + dgr.Cells[3].Value.ToString() + "','" + dgr.Cells[4].Value.ToString() + "','" + dgr.Cells[5].Value.ToString() + "','"
                                                                                         + dgr.Cells[6].Value.ToString() + "','" + dgr.Cells[7].Value.ToString() + "','" + dgr.Cells[8].Value.ToString() + "','"
                                                                                         + dgr.Cells[9].Value.ToString() + "','" + dgr.Cells[10].Value.ToString() + "')";
                                        OleDbCommand cmdIn = new OleDbCommand(strIn, cnn);
                                        cmdIn.ExecuteNonQuery();
                                    }
                                }
                                cnn.Close();
                                //reset data
                                dgv_nwBOM.Columns.Clear();
                                File.Delete(@Application.StartupPath + "\\tem\\NewBom.xlsx");
                            }                            
                        }
                    }                   
                }               
            }           
        }

        private void rbtn_newForm_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtn_newForm.Checked == true)
            {
                dgv_nwBOM.Columns.Clear();
                groupBox2.Enabled = true;
            }
            else
            {
                dgv_nwBOM.Columns.Clear();
                groupBox2.Enabled = false;
            }
        }

        private void rbtn_availableForm_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtn_availableForm.Checked == true)
            {
                groupBox3.Enabled = true;
            }
            else
            {
                groupBox3.Enabled = false;
            }
        }

        private void btn_createForm_Click(object sender, EventArgs e)
        {
            timer1.Start();
            strArrNg = new string[11];
            countNg = 0;
            //Tao file excel form            
            //Mo file excel form
            Workbook wb = new Workbook();
            Worksheet ws = wb.Worksheets[0];
            DataTable dt1 = new DataTable();
            dt1.Clear();
            dt1.Columns.Add("Line");
            dt1.Columns.Add("Model");
            dt1.Columns.Add("Ma_NVL");
            dt1.Columns.Add("Mo_ta");
            dt1.Columns.Add("Vi_tri");
            dt1.Columns.Add("Diem_gan");
            dt1.Columns.Add("Maker");
            dt1.Columns.Add("Maker_Part");
            dt1.Columns.Add("Cong_doan");
            dt1.Columns.Add("So_luong");
            dt1.Columns.Add("Su_dung");
            ws.InsertDataTable(dt1, true, 1, 1);
            ws.Columns[1].ColumnWidth = 15;
            ws.Columns[2].ColumnWidth = 15;
            ws.Columns[3].ColumnWidth = 15;
            ws.Columns[6].ColumnWidth = 20;
            ws.Columns[7].ColumnWidth = 25;
            ws.Columns[8].ColumnWidth = 15;
            ws.Columns[10].ColumnWidth = 15;
            ws.Rows[0].BorderInside(LineStyleType.Thin, Color.Black);
            ws.Rows[0].BorderAround(LineStyleType.Thin, Color.Black);
            ws.Rows[0].Style.Color = Color.Yellow;
            ws.Rows[0].Style.HorizontalAlignment = HorizontalAlignType.Center;
                
            wb.SaveToFile(@Application.StartupPath + "\\tem\\NewBom.xlsx", ExcelVersion.Version2007);
            Excel.Application excelBom = new Microsoft.Office.Interop.Excel.Application();
            Excel.Workbook wbBom = excelBom.Workbooks.Open(@Application.StartupPath + "\\tem\\NewBom.xlsx", 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
            Microsoft.Office.Interop.Excel.Worksheet wsBom = (Microsoft.Office.Interop.Excel.Worksheet)wbBom.Worksheets.get_Item(1);
            
            excelBom.Visible = true;

            //Dien data -> Save -> Load file excel filled -> Hien thi database          
            Excel.AppEvents_WorkbookBeforeSaveEventHandler WorkbookBeforeSave = new Excel.AppEvents_WorkbookBeforeSaveEventHandler(excelBom_WorkbookBeforeSave);
            excelBom.WorkbookBeforeSave += excelBom_WorkbookBeforeSave;

            Excel.AppEvents_WorkbookBeforeCloseEventHandler WorkbookBeforeClose = new Excel.AppEvents_WorkbookBeforeCloseEventHandler(excelBom_WorkbookBeforeClose);
            excelBom.WorkbookBeforeClose += excelBom_WorkbookBeforeClose;
        }

        private static void excelBom_WorkbookBeforeSave(Excel.Workbook wb, bool saveWb, ref bool cacel)
        {
            MessageBox.Show("Kiểm tra lại thông tin BOM.\nVà tắt file để load BOM vào chương trình!", "NewBom", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);           
        }

        public static bool chk;
        private static void excelBom_WorkbookBeforeClose(Excel.Workbook wb, ref bool cacel)
        {
            chk = true;            
        }

        private void btn_showData_Click(object sender, EventArgs e)
        {
            strArrNg = new string[11];
            countNg = 0;
            //Load file excel filled -> Hien thi database
            dgv_nwBOM.Visible = true;
            string fname = "";
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Excel File Dialog";
            fdlg.InitialDirectory = @"C:\";
            fdlg.Filter = "Excel Files |*.xlsx|Excel Files |*.csv|All Files (*.*)|*.*";
            fdlg.FilterIndex = 3;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                fname = fdlg.FileName;
            }

            if(fname != "")
            {
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook xlWB = xlApp.Workbooks.Open(fname);
                Microsoft.Office.Interop.Excel._Worksheet xlWS = xlWB.Sheets[1];
                Microsoft.Office.Interop.Excel.Range XlRag = xlWS.UsedRange;

                int rowCount = XlRag.Rows.Count;
                int colCount = XlRag.Columns.Count;

                dgv_nwBOM.ColumnCount = colCount;
                dgv_nwBOM.RowCount = rowCount;

                for (int i = 1; i <= rowCount; i++)
                {
                    for (int j = 1; j <= colCount; j++)
                    {
                        if (XlRag.Cells[i, j] != null && XlRag.Cells[i, j].Value2 != null)
                        {
                            dgv_nwBOM.Rows[i - 1].Cells[j - 1].Value = XlRag.Cells[i, j].Value2.ToString();
                        }
                    }
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();

                Marshal.ReleaseComObject(XlRag);
                Marshal.ReleaseComObject(xlWS);

                xlWB.Close();
                Marshal.ReleaseComObject(xlWB);

                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
            }
            
            if(dgv_nwBOM.Columns.Count > 0)
            {
                getNameColumns(0, 0, "Line");
                getNameColumns(1, 0, "Model");
                getNameColumns(2, 0, "Ma_NVL");
                getNameColumns(3, 0, "Mo_ta");
                getNameColumns(4, 0, "Vi_tri");
                getNameColumns(5, 0, "Diem_gan");
                getNameColumns(6, 0, "Maker");
                getNameColumns(7, 0, "Maker_Part");
                getNameColumns(8, 0, "Cong_doan");
                getNameColumns(9, 0, "So_luong");
                getNameColumns(10, 0, "Su_dung");
                if (strArrNg[0] != null)
                {
                    string toDisply = string.Join("\n", strArrNg);
                    MessageBox.Show("Trường dữ liệu bị sai.\nThay đổi lại như sau :\n" + toDisply, "NewBOM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }                
            }
        }

        private void btn_deleteAll_Click(object sender, EventArgs e)
        {
            dgv_nwBOM.Columns.Clear();
        }
        
        public void getNameColumns(int indexCol, int indexRow, string namCol)
        {            
            if (dgv_nwBOM.Rows[indexRow].Cells[indexCol].Value.ToString() != namCol)
            {
                strArrNg[countNg] = dgv_nwBOM.Rows[indexRow].Cells[indexCol].Value.ToString() + " = " + namCol;                
                countNg++;
            }            
        }

        public void loadExcel(DataGridView dgt)
        {           
            //Load file excel filled -> Hien thi database
            dgt.Visible = true;            
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook xlWB = xlApp.Workbooks.Open(@Application.StartupPath + "\\tem\\NewBom.xlsx");
            Microsoft.Office.Interop.Excel._Worksheet xlWS = xlWB.Sheets[1];
            Microsoft.Office.Interop.Excel.Range XlRag = xlWS.UsedRange;

            int rowCount = XlRag.Rows.Count;
            int colCount = XlRag.Columns.Count;

            dgt.ColumnCount = colCount;
            dgt.RowCount = rowCount;

            for (int i = 1; i <= rowCount; i++)
            {
                for (int j = 1; j <= colCount; j++)
                {
                    if (XlRag.Cells[i, j] != null && XlRag.Cells[i, j].Value2 != null)
                    {
                        dgt.Rows[i - 1].Cells[j - 1].Value = XlRag.Cells[i, j].Value2.ToString();
                    }
                }
            }
            GC.Collect();
            GC.WaitForPendingFinalizers();

            Marshal.ReleaseComObject(XlRag);
            Marshal.ReleaseComObject(xlWS);

            xlWB.Close();
            Marshal.ReleaseComObject(xlWB);

            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(chk == true)
            {
                chk = false;
                timer1.Stop();
                loadExcel(dgv_nwBOM);               
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@Application.StartupPath + "\\Picture\\zMaterBOM.xlsx");
        }

        public bool chk_data(DataGridView dgv)
        {
            int errData = 0;
            foreach (DataGridViewRow dgr in dgv.Rows)
            {
                if (dgr.Index == 0)
                {
                    continue;
                }
                //Line
                string masterStr = dgv.Rows[1].Cells[0].Value.ToString();
                if (dgr.Cells[0].Value.ToString() == "3" || dgr.Cells[0].Value.ToString() == "6" || dgr.Cells[0].Value.ToString() == "7")
                {
                    if(dgr.Cells[0].Value.ToString() != masterStr)
                    {
                        errData++;
                        dgr.Cells[0].Style.BackColor = Color.Red;
                    }
                    else
                    {
                        dgr.Cells[0].Style.BackColor = Color.White;
                    }
                }
                else
                {
                    errData++;
                    dgr.Cells[0].Style.BackColor = Color.Red;
                }
                //Model
                if (dgr.Cells[1].Value.ToString() != "")
                {
                    int err = 0;
                    foreach(char c in dgr.Cells[1].Value.ToString())
                    {
                        if(!Char.IsUpper(c))
                        {
                            int kq;
                            if((int.TryParse(c.ToString(), out kq) == false) && (c != '-'))
                            {
                                err++;
                                break;
                            }          
                        }
                    }

                    if(err == 0)
                    {
                        dgr.Cells[1].Style.BackColor = Color.White;
                    }
                    else
                    {
                        errData++;
                        dgr.Cells[1].Style.BackColor = Color.Red;
                    }
                }
                //Code
                if(dgr.Cells[2].Value.ToString().Length != 11)
                {
                    errData++;
                    dgr.Cells[2].Style.BackColor = Color.Red;
                }
                else
                {
                    dgr.Cells[2].Style.BackColor = Color.White;
                }
                //Qty
                int qty;
                if(int.TryParse(dgr.Cells[5].Value.ToString(), out qty) == false)
                {
                    errData++;
                    dgr.Cells[5].Style.BackColor = Color.Red;
                }
                else
                {
                    dgr.Cells[5].Style.BackColor = Color.White;
                }
                //Process
                if (dgr.Cells[8].Value.ToString() != "SMD")
                {
                    errData++;
                    dgr.Cells[8].Style.BackColor = Color.Red;
                }
                else
                {
                    dgr.Cells[8].Style.BackColor = Color.White;
                }
                //Qty Roll
                int qtyRoll;
                if(int.TryParse(dgr.Cells[9].Value.ToString(), out qtyRoll) == false)
                {
                    errData++;
                    dgr.Cells[9].Style.BackColor = Color.Red;
                }
                else
                {
                    dgr.Cells[9].Style.BackColor = Color.White;
                }
                //Status code
                if(dgr.Cells[10].Value.ToString() != "Yes" && dgr.Cells[10].Value.ToString() != "No")
                {
                    errData++;
                    dgr.Cells[10].Style.BackColor = Color.Red;
                }
                else
                {
                    dgr.Cells[10].Style.BackColor = Color.White;
                }
            }

            if(errData == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
