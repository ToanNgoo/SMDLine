﻿namespace ManageMaterialPBA
{
    partial class NewBOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_nwBOM = new System.Windows.Forms.DataGridView();
            this.btn_showData = new System.Windows.Forms.Button();
            this.btn_nmBOM = new System.Windows.Forms.Button();
            this.btn_createForm = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtn_availableForm = new System.Windows.Forms.RadioButton();
            this.rbtn_newForm = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_deleteAll = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_nwBOM)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(269, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tạo BOM New Model";
            // 
            // dgv_nwBOM
            // 
            this.dgv_nwBOM.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgv_nwBOM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_nwBOM.Location = new System.Drawing.Point(6, 173);
            this.dgv_nwBOM.Name = "dgv_nwBOM";
            this.dgv_nwBOM.Size = new System.Drawing.Size(1150, 370);
            this.dgv_nwBOM.TabIndex = 1;
            // 
            // btn_showData
            // 
            this.btn_showData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_showData.Location = new System.Drawing.Point(9, 20);
            this.btn_showData.Name = "btn_showData";
            this.btn_showData.Size = new System.Drawing.Size(90, 60);
            this.btn_showData.TabIndex = 2;
            this.btn_showData.Text = "Tải dữ liệu";
            this.btn_showData.UseVisualStyleBackColor = false;
            this.btn_showData.Click += new System.EventHandler(this.btn_showData_Click);
            // 
            // btn_nmBOM
            // 
            this.btn_nmBOM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_nmBOM.Location = new System.Drawing.Point(9, 20);
            this.btn_nmBOM.Name = "btn_nmBOM";
            this.btn_nmBOM.Size = new System.Drawing.Size(70, 60);
            this.btn_nmBOM.TabIndex = 3;
            this.btn_nmBOM.Text = "Tạo BOM mới";
            this.btn_nmBOM.UseVisualStyleBackColor = false;
            this.btn_nmBOM.Click += new System.EventHandler(this.btn_nmBOM_Click);
            // 
            // btn_createForm
            // 
            this.btn_createForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_createForm.Location = new System.Drawing.Point(10, 20);
            this.btn_createForm.Name = "btn_createForm";
            this.btn_createForm.Size = new System.Drawing.Size(90, 60);
            this.btn_createForm.TabIndex = 4;
            this.btn_createForm.Text = "Tạo Form mới";
            this.btn_createForm.UseVisualStyleBackColor = false;
            this.btn_createForm.Click += new System.EventHandler(this.btn_createForm_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox1.Controls.Add(this.rbtn_availableForm);
            this.groupBox1.Controls.Add(this.rbtn_newForm);
            this.groupBox1.Location = new System.Drawing.Point(7, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(150, 90);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Nguồn dữ liệu";
            // 
            // rbtn_availableForm
            // 
            this.rbtn_availableForm.AutoSize = true;
            this.rbtn_availableForm.Location = new System.Drawing.Point(7, 60);
            this.rbtn_availableForm.Name = "rbtn_availableForm";
            this.rbtn_availableForm.Size = new System.Drawing.Size(113, 17);
            this.rbtn_availableForm.TabIndex = 1;
            this.rbtn_availableForm.TabStop = true;
            this.rbtn_availableForm.Text = "Dùng BOM có sẵn";
            this.rbtn_availableForm.UseVisualStyleBackColor = true;
            this.rbtn_availableForm.CheckedChanged += new System.EventHandler(this.rbtn_availableForm_CheckedChanged);
            // 
            // rbtn_newForm
            // 
            this.rbtn_newForm.AutoSize = true;
            this.rbtn_newForm.Location = new System.Drawing.Point(7, 25);
            this.rbtn_newForm.Name = "rbtn_newForm";
            this.rbtn_newForm.Size = new System.Drawing.Size(97, 17);
            this.rbtn_newForm.TabIndex = 0;
            this.rbtn_newForm.TabStop = true;
            this.rbtn_newForm.Text = "Tạo Form BOM";
            this.rbtn_newForm.UseVisualStyleBackColor = true;
            this.rbtn_newForm.CheckedChanged += new System.EventHandler(this.rbtn_newForm_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btn_createForm);
            this.groupBox2.Location = new System.Drawing.Point(170, 71);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(192, 90);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tạo Form BOM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(110, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 39);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tạo file Excel \r\nBOM mới theo \r\nForm có sẵn";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.btn_showData);
            this.groupBox3.Location = new System.Drawing.Point(374, 71);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(208, 90);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dùng BOM có sẵn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(108, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 39);
            this.label2.TabIndex = 3;
            this.label2.Text = "Load file Excel \r\nBOM đã có\r\nChú ý : Form BOM";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.btn_deleteAll);
            this.groupBox4.Controls.Add(this.btn_nmBOM);
            this.groupBox4.Location = new System.Drawing.Point(594, 71);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(249, 90);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Phím chức năng";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button1.Location = new System.Drawing.Point(169, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 60);
            this.button1.TabIndex = 5;
            this.button1.Text = "Kiểm tra Master dữ liệu BOM";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_deleteAll
            // 
            this.btn_deleteAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_deleteAll.Location = new System.Drawing.Point(89, 20);
            this.btn_deleteAll.Name = "btn_deleteAll";
            this.btn_deleteAll.Size = new System.Drawing.Size(70, 60);
            this.btn_deleteAll.TabIndex = 4;
            this.btn_deleteAll.Text = "Xóa dữ liệu";
            this.btn_deleteAll.UseVisualStyleBackColor = false;
            this.btn_deleteAll.Click += new System.EventHandler(this.btn_deleteAll_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(856, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 140);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Location = new System.Drawing.Point(7, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(836, 59);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 548);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1164, 22);
            this.statusStrip1.TabIndex = 13;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // NewBOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1164, 570);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgv_nwBOM);
            this.Name = "NewBOM";
            this.Text = "NewBOM";
            this.Load += new System.EventHandler(this.NewBOM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_nwBOM)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv_nwBOM;
        private System.Windows.Forms.Button btn_showData;
        private System.Windows.Forms.Button btn_nmBOM;
        private System.Windows.Forms.Button btn_createForm;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtn_availableForm;
        private System.Windows.Forms.RadioButton rbtn_newForm;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_deleteAll;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}