﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManageMaterialPBA
{
    public partial class BOM : Form
    {
        database dtb = new database();
        database_1 dtb1 = new database_1();
        public string _userr, _passs;

        public BOM(string userr, string passs)
        {
            InitializeComponent();
            _userr = userr;
            _passs = passs;
        }

        private void dgv_bom_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            dgv_bom.ColumnHeadersDefaultCellStyle.Font = new Font(dgv_bom.Font, FontStyle.Bold);
            dgv_bom.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv_bom.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void BOM_Load(object sender, EventArgs e)
        {
            //Load anh
            pictureBox1.Image = new Bitmap(@Application.StartupPath + "\\Picture\\SDIV.PNG");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            dtb.get_model(cbb_model);
            if(_userr != "" && _passs != "")
            {
                //Admin
                if(dtb1.get_adLogin(_userr, _passs) == true)
                {
                    côngCụToolStripMenuItem.Visible = true;
                }
                else//Not admin
                {
                    côngCụToolStripMenuItem.Visible = false;
                } 
            }
            else
            {
                côngCụToolStripMenuItem.Visible = false;
            }

            toolStripStatusLabel1.Text = dtb.get_name(_userr,_passs);
            
            //DataTable bom = new DataTable();
            //bom = dtb.loadtransport();
            //dgv_bom.DataSource = bom.DefaultView;
        }

        private void btn_exeBom_Click(object sender, EventArgs e)
        {
            DataTable bom = new DataTable();
            if(cbb_model.Text == "")
            {
                bom = dtb.loadtransport();
            }
            else
            {
                bom = dtb.loadtransportml(cbb_model.Text);
            }

            dgv_bom.DataSource = bom.DefaultView;
        }

        private void updateBOMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool Isopen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "UpdateBOM")
                {
                    Isopen = true;
                    f.BringToFront();
                    break;
                }
            }
            if (Isopen == false)
            {
                UpdateBOM Upbom = new UpdateBOM(_userr, _passs);
                Upbom.Show();
            }
        }

        private void newBOMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool Isopen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "NewBOM")
                {
                    Isopen = true;
                    f.BringToFront();
                    break;
                }
            }
            if (Isopen == false)
            {
                NewBOM Nebom = new NewBOM(_userr, _passs);
                Nebom.Show();
            }
        }

        private void btn_capNhat_Click(object sender, EventArgs e)
        {
            dtb.get_model(cbb_model);
        }       
    }
}
