﻿namespace ManageMaterialPBA
{
    partial class UpdateBOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_line = new System.Windows.Forms.Label();
            this.lbl_mol = new System.Windows.Forms.Label();
            this.lbl_cod = new System.Windows.Forms.Label();
            this.dgv_updBOM = new System.Windows.Forms.DataGridView();
            this.cbb_line = new System.Windows.Forms.ComboBox();
            this.cbb_mol = new System.Windows.Forms.ComboBox();
            this.cbb_cod = new System.Windows.Forms.ComboBox();
            this.btn_upBOM = new System.Windows.Forms.Button();
            this.cbb_vendr = new System.Windows.Forms.ComboBox();
            this.lbl_vendr = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_lydo = new System.Windows.Forms.TextBox();
            this.cbx_lydo = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_updBOM)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(302, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(270, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cập nhật BOM NVL";
            // 
            // lbl_line
            // 
            this.lbl_line.AutoSize = true;
            this.lbl_line.Location = new System.Drawing.Point(9, 25);
            this.lbl_line.Name = "lbl_line";
            this.lbl_line.Size = new System.Drawing.Size(27, 13);
            this.lbl_line.TabIndex = 1;
            this.lbl_line.Text = "Line";
            // 
            // lbl_mol
            // 
            this.lbl_mol.AutoSize = true;
            this.lbl_mol.Location = new System.Drawing.Point(9, 61);
            this.lbl_mol.Name = "lbl_mol";
            this.lbl_mol.Size = new System.Drawing.Size(36, 13);
            this.lbl_mol.TabIndex = 2;
            this.lbl_mol.Text = "Model";
            // 
            // lbl_cod
            // 
            this.lbl_cod.AutoSize = true;
            this.lbl_cod.Location = new System.Drawing.Point(190, 25);
            this.lbl_cod.Name = "lbl_cod";
            this.lbl_cod.Size = new System.Drawing.Size(49, 13);
            this.lbl_cod.TabIndex = 3;
            this.lbl_cod.Text = "Ma_NVL";
            // 
            // dgv_updBOM
            // 
            this.dgv_updBOM.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgv_updBOM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_updBOM.Location = new System.Drawing.Point(7, 173);
            this.dgv_updBOM.Name = "dgv_updBOM";
            this.dgv_updBOM.Size = new System.Drawing.Size(1150, 370);
            this.dgv_updBOM.TabIndex = 4;
            // 
            // cbb_line
            // 
            this.cbb_line.FormattingEnabled = true;
            this.cbb_line.Location = new System.Drawing.Point(64, 21);
            this.cbb_line.Name = "cbb_line";
            this.cbb_line.Size = new System.Drawing.Size(100, 21);
            this.cbb_line.TabIndex = 5;
            this.cbb_line.SelectedIndexChanged += new System.EventHandler(this.cbb_line_SelectedIndexChanged);
            // 
            // cbb_mol
            // 
            this.cbb_mol.FormattingEnabled = true;
            this.cbb_mol.Location = new System.Drawing.Point(64, 57);
            this.cbb_mol.Name = "cbb_mol";
            this.cbb_mol.Size = new System.Drawing.Size(100, 21);
            this.cbb_mol.TabIndex = 6;
            this.cbb_mol.SelectedIndexChanged += new System.EventHandler(this.cbb_mol_SelectedIndexChanged);
            // 
            // cbb_cod
            // 
            this.cbb_cod.FormattingEnabled = true;
            this.cbb_cod.Location = new System.Drawing.Point(256, 21);
            this.cbb_cod.Name = "cbb_cod";
            this.cbb_cod.Size = new System.Drawing.Size(120, 21);
            this.cbb_cod.TabIndex = 7;
            this.cbb_cod.SelectedIndexChanged += new System.EventHandler(this.cbb_cod_SelectedIndexChanged);
            // 
            // btn_upBOM
            // 
            this.btn_upBOM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_upBOM.Location = new System.Drawing.Point(7, 31);
            this.btn_upBOM.Name = "btn_upBOM";
            this.btn_upBOM.Size = new System.Drawing.Size(85, 40);
            this.btn_upBOM.TabIndex = 8;
            this.btn_upBOM.Text = "Update/Insert BOM";
            this.btn_upBOM.UseVisualStyleBackColor = false;
            this.btn_upBOM.Click += new System.EventHandler(this.btn_upBOM_Click);
            // 
            // cbb_vendr
            // 
            this.cbb_vendr.FormattingEnabled = true;
            this.cbb_vendr.Location = new System.Drawing.Point(256, 57);
            this.cbb_vendr.Name = "cbb_vendr";
            this.cbb_vendr.Size = new System.Drawing.Size(120, 21);
            this.cbb_vendr.TabIndex = 11;
            this.cbb_vendr.SelectedIndexChanged += new System.EventHandler(this.cbb_vendr_SelectedIndexChanged);
            // 
            // lbl_vendr
            // 
            this.lbl_vendr.AutoSize = true;
            this.lbl_vendr.Location = new System.Drawing.Point(190, 61);
            this.lbl_vendr.Name = "lbl_vendr";
            this.lbl_vendr.Size = new System.Drawing.Size(37, 13);
            this.lbl_vendr.TabIndex = 10;
            this.lbl_vendr.Text = "Maker";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox1.Controls.Add(this.cbb_mol);
            this.groupBox1.Controls.Add(this.cbb_vendr);
            this.groupBox1.Controls.Add(this.lbl_line);
            this.groupBox1.Controls.Add(this.lbl_vendr);
            this.groupBox1.Controls.Add(this.lbl_mol);
            this.groupBox1.Controls.Add(this.lbl_cod);
            this.groupBox1.Controls.Add(this.cbb_cod);
            this.groupBox1.Controls.Add(this.cbb_line);
            this.groupBox1.Location = new System.Drawing.Point(8, 69);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(394, 90);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin cơ bản";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.btn_upBOM);
            this.groupBox2.Location = new System.Drawing.Point(689, 69);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(187, 90);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Phím chức năng";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(8, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(868, 58);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(892, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(265, 130);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Lý do thay đổi";
            // 
            // txt_lydo
            // 
            this.txt_lydo.Location = new System.Drawing.Point(106, 57);
            this.txt_lydo.Name = "txt_lydo";
            this.txt_lydo.Size = new System.Drawing.Size(140, 20);
            this.txt_lydo.TabIndex = 13;
            // 
            // cbx_lydo
            // 
            this.cbx_lydo.FormattingEnabled = true;
            this.cbx_lydo.Location = new System.Drawing.Point(106, 21);
            this.cbx_lydo.Name = "cbx_lydo";
            this.cbx_lydo.Size = new System.Drawing.Size(140, 21);
            this.cbx_lydo.TabIndex = 14;
            this.cbx_lydo.SelectedIndexChanged += new System.EventHandler(this.cbx_lydo_SelectedIndexChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.cbx_lydo);
            this.groupBox4.Controls.Add(this.txt_lydo);
            this.groupBox4.Location = new System.Drawing.Point(416, 70);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(259, 89);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thông tin bổ sung";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "→ Điền nội dung";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 547);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1164, 22);
            this.statusStrip1.TabIndex = 17;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button1.Location = new System.Drawing.Point(100, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 40);
            this.button1.TabIndex = 9;
            this.button1.Text = "Xóa dữ liệu";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // UpdateBOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1164, 569);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgv_updBOM);
            this.Name = "UpdateBOM";
            this.Text = "UpdateBOM";
            this.Load += new System.EventHandler(this.UpdateBOM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_updBOM)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_line;
        private System.Windows.Forms.Label lbl_mol;
        private System.Windows.Forms.Label lbl_cod;
        private System.Windows.Forms.DataGridView dgv_updBOM;
        private System.Windows.Forms.ComboBox cbb_line;
        private System.Windows.Forms.ComboBox cbb_mol;
        private System.Windows.Forms.ComboBox cbb_cod;
        private System.Windows.Forms.Button btn_upBOM;
        private System.Windows.Forms.ComboBox cbb_vendr;
        private System.Windows.Forms.Label lbl_vendr;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txt_lydo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbx_lydo;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button button1;
    }
}